<script>
$(document).ready(function() {        
    $.ajax({
    	url : '/WikiweetAPI/wiki',
    	type : 'GET',
    	dataType : 'json',
    	success : function(data) {
    		$.each(data, function(key, article){
    			if(article.idEtat=="1"){
    				$("#wikis").append('<div class="invalide">' + article.titre + '</div>');
    			}
    			if(article.idEtat=="2"){
    				$("#acorriger").append('<div class="acorriger">' + article.titre + '</div>');
    			}
    			if (article.idEtat=="3"){
    				$("#corriges").append('<div class="corriges">' + article.titre + '</div>');
    			}
    			if (article.idEtat=="4"){
    				$("#valides").append('<div class="valides">' + article.titre + '</div>');
    			}
    			if (article.idEtat=="5"){
    				$("#archives").append('<div class="archives">' + article.titre + '</div>');
    			}
            
    	   	});
        }
    }
           );
    });
    
//$( function() {
  //  $( "div.droptrue" ).sortable({
    //	connectWith : "div.droptrue"
   // });
  //} );

    
$(function(){
	  dragula([document.getElementById("wikis"), document.getElementById("acorriger"), document.getElementById("corriges"), document.getElementById("valides"), document.getElementById("archives")], {
	    revertOnSpill: true
	  })
	  .on('drag', function(el) {	
		  // add 'is-moving' class to element being dragged
		  el.classList.add('is-moving');
	  })
	  .on('dragend', function(el) {	
	    // remove 'is-moving' class from element after dragging has stopped
	    el.classList.remove('is-moving');
	   // document.getElementById("wikis").classList.item(0);)
	   // document.getElementById("acorriger").classList.item(0);
	   // document.getElementById("corriges").classList.item(0);
	  	// document.getElementById("valides").classList.item(0);
	  	// document.getElementById("archives").classList.item(0);
	  	
	    			})
	    }

	    // add the 'is-moved' class for 600ms then remove it
	    window.setTimeout(function() {
	      el.classList.add('is-moved');
	      window.setTimeout(function() {
	        el.classList.remove('is-moved');
	      }, 600);
	    }, 100);
	  });	
		
	}());




</script>